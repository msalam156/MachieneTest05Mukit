import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'SalesMonitoringSystem';
  
  // getData(data:any){
  //   console.log(data.password);
  //   console.log(data.username);
  //   this.route.navigateByUrl('visit');

  // }
}
